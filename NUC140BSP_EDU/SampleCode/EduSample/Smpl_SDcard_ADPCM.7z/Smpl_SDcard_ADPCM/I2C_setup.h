
#define ENABLE_I2C0
#define I2C_ADDR 0x1A
