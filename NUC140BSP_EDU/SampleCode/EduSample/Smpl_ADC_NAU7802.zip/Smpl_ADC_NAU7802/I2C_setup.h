
#define ENABLE_I2C1
#define	I2C_ADDR 0xA6
